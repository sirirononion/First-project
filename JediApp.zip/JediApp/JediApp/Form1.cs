﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace JediApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            lblJediHelp.Text = "To Remove Jedi from the list,\n select the one you want\n and hit the 'Remove Jedi' button";
            lblEraseJedi.Text = "Muhhaaaaaa";
            Font font2 = new Font("Times New Roman", 20);
            lblEraseJedi.Font = font2;
        }

        private void btnAddPerson_Click(object sender, EventArgs e)
        {
            lbJediList.Items.Add(tbJediName.Text);
            this.BackColor = Color.White;
            ChangeColors();
        }

        private void btnRemoveJedi_Click(object sender, EventArgs e)
        {

            if (lbJediList.SelectedItem != null)
            {
                lbJediList.Items.Remove(lbJediList.SelectedItem);
                this.BackColor = Color.Black;
                ChangeColors();
            }
            else
            {
              MessageBox.Show("You need to add a Jedi to the list");
            }
        }

        private void btnRemoveJedi_MouseHover(object sender, EventArgs e)
        {
            lblEraseJedi.Visible = true;
            pbSith.Visible = true;
        }

        private void btnRemoveJedi_MouseLeave(object sender, EventArgs e)
        {
            lblEraseJedi.Visible = false;
            pbSith.Visible = false;
        }

        private void lbJediList_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Jedi Vaporized");

        }


        private void ChangeColors()
        {

            //test for colors
            if (this.BackColor == Color.Black)
            {
                lblAddJediText.ForeColor = Color.White;
                lblEraseJedi.ForeColor = Color.White;
                lblJediHelp.ForeColor = Color.White;
                lblRemoveJedi.ForeColor = Color.White;
                //lblEraseJedi.Visible = false;
                //pbSith.Visible = false;
            }
            else
            {
                lblAddJediText.ForeColor = Color.Black;
                lblEraseJedi.ForeColor = Color.Black;
                lblJediHelp.ForeColor = Color.Black;
                lblRemoveJedi.ForeColor = Color.Black;
                //lblEraseJedi.Visible = true;
               //pbSith.Visible = true;
            }
        }

        private void lblAddJediText_Click(object sender, EventArgs e)
        {

        }

    }
}

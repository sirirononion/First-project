﻿namespace JediApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbJediList = new System.Windows.Forms.ListBox();
            this.tbJediName = new System.Windows.Forms.TextBox();
            this.btnAddJedi = new System.Windows.Forms.Button();
            this.btnRemoveJedi = new System.Windows.Forms.Button();
            this.lblJediHelp = new System.Windows.Forms.Label();
            this.lblAddJediText = new System.Windows.Forms.Label();
            this.lblRemoveJedi = new System.Windows.Forms.Label();
            this.pbSith = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblEraseJedi = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbSith)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbJediList
            // 
            this.lbJediList.FormattingEnabled = true;
            this.lbJediList.Location = new System.Drawing.Point(764, 57);
            this.lbJediList.Name = "lbJediList";
            this.lbJediList.Size = new System.Drawing.Size(241, 316);
            this.lbJediList.TabIndex = 2;
            this.lbJediList.SelectedIndexChanged += new System.EventHandler(this.lbJediList_SelectedIndexChanged);
            // 
            // tbJediName
            // 
            this.tbJediName.Location = new System.Drawing.Point(542, 57);
            this.tbJediName.Name = "tbJediName";
            this.tbJediName.Size = new System.Drawing.Size(188, 20);
            this.tbJediName.TabIndex = 3;
            // 
            // btnAddJedi
            // 
            this.btnAddJedi.Location = new System.Drawing.Point(542, 95);
            this.btnAddJedi.Name = "btnAddJedi";
            this.btnAddJedi.Size = new System.Drawing.Size(185, 51);
            this.btnAddJedi.TabIndex = 0;
            this.btnAddJedi.Text = "Add Jedi";
            this.btnAddJedi.UseVisualStyleBackColor = true;
            this.btnAddJedi.Click += new System.EventHandler(this.btnAddPerson_Click);
            // 
            // btnRemoveJedi
            // 
            this.btnRemoveJedi.Location = new System.Drawing.Point(542, 322);
            this.btnRemoveJedi.Name = "btnRemoveJedi";
            this.btnRemoveJedi.Size = new System.Drawing.Size(185, 51);
            this.btnRemoveJedi.TabIndex = 4;
            this.btnRemoveJedi.Text = "Remove Jedi";
            this.btnRemoveJedi.UseVisualStyleBackColor = true;
            this.btnRemoveJedi.Click += new System.EventHandler(this.btnRemoveJedi_Click);
            this.btnRemoveJedi.MouseLeave += new System.EventHandler(this.btnRemoveJedi_MouseLeave);
            this.btnRemoveJedi.MouseHover += new System.EventHandler(this.btnRemoveJedi_MouseHover);
            // 
            // lblJediHelp
            // 
            this.lblJediHelp.AutoSize = true;
            this.lblJediHelp.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJediHelp.Location = new System.Drawing.Point(539, 218);
            this.lblJediHelp.Name = "lblJediHelp";
            this.lblJediHelp.Size = new System.Drawing.Size(74, 18);
            this.lblJediHelp.TabIndex = 5;
            this.lblJediHelp.Text = "lbJediHelp";
            this.lblJediHelp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAddJediText
            // 
            this.lblAddJediText.AutoSize = true;
            this.lblAddJediText.Location = new System.Drawing.Point(539, 32);
            this.lblAddJediText.Name = "lblAddJediText";
            this.lblAddJediText.Size = new System.Drawing.Size(74, 13);
            this.lblAddJediText.TabIndex = 6;
            this.lblAddJediText.Text = "Add Jedi Here";
            this.lblAddJediText.Click += new System.EventHandler(this.lblAddJediText_Click);
            // 
            // lblRemoveJedi
            // 
            this.lblRemoveJedi.AutoSize = true;
            this.lblRemoveJedi.Location = new System.Drawing.Point(542, 303);
            this.lblRemoveJedi.Name = "lblRemoveJedi";
            this.lblRemoveJedi.Size = new System.Drawing.Size(95, 13);
            this.lblRemoveJedi.TabIndex = 7;
            this.lblRemoveJedi.Text = "Remove Jedi Here";
            // 
            // pbSith
            // 
            this.pbSith.Image = global::JediApp.Properties.Resources.sith;
            this.pbSith.Location = new System.Drawing.Point(542, 413);
            this.pbSith.Name = "pbSith";
            this.pbSith.Size = new System.Drawing.Size(248, 141);
            this.pbSith.TabIndex = 8;
            this.pbSith.TabStop = false;
            this.pbSith.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::JediApp.Properties.Resources.Yoda_TPM_RotS;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(501, 564);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblEraseJedi
            // 
            this.lblEraseJedi.AutoSize = true;
            this.lblEraseJedi.Location = new System.Drawing.Point(796, 423);
            this.lblEraseJedi.Name = "lblEraseJedi";
            this.lblEraseJedi.Size = new System.Drawing.Size(63, 13);
            this.lblEraseJedi.TabIndex = 9;
            this.lblEraseJedi.Text = "lblEraseJedi";
            this.lblEraseJedi.Visible = false;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnAddJedi;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1025, 566);
            this.Controls.Add(this.lblEraseJedi);
            this.Controls.Add(this.pbSith);
            this.Controls.Add(this.lblRemoveJedi);
            this.Controls.Add(this.lblAddJediText);
            this.Controls.Add(this.lblJediHelp);
            this.Controls.Add(this.btnRemoveJedi);
            this.Controls.Add(this.tbJediName);
            this.Controls.Add(this.lbJediList);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnAddJedi);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "JediApp";
            ((System.ComponentModel.ISupportInitialize)(this.pbSith)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddJedi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListBox lbJediList;
        private System.Windows.Forms.TextBox tbJediName;
        private System.Windows.Forms.Button btnRemoveJedi;
        private System.Windows.Forms.Label lblJediHelp;
        private System.Windows.Forms.Label lblAddJediText;
        private System.Windows.Forms.Label lblRemoveJedi;
        private System.Windows.Forms.PictureBox pbSith;
        private System.Windows.Forms.Label lblEraseJedi;
    }
}

